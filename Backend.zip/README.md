# URL Shortener Backend

A Node.js/Express backend for URL shortening service.

## Project Structure

```
backend/
├── controllers/
├── middleware/
│   └── logger.js
├── models/
│   └── Url.js
├── routes/
│   └── urlRoutes.js
├── .env
├── package.json
├── package-lock.json
└── server.js
```

## Setup

1. Clone the repository
2. Navigate to the `backend` directory
3. Run `npm install`
4. Create a `.env` file with your MongoDB connection string
5. Start the server with `npm start`

## Features

- URL Shortening
- URL Redirection
- Click Tracking
- URL Expiration
- Request Logging

## API Endpoints

- POST `/shorturls` - Create a new short URL
- GET `/:shortcode` - Redirect to original URL

## Technologies Used

- Node.js
- Express.js
- MongoDB
- Mongoose
- CORS
- dotenv
- moment.js

## License

ISC License

## Contributing

Feel free to submit issues and enhancement requests!
