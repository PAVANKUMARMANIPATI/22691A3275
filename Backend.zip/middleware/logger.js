const fs = require('fs');
const path = require('path');
const moment = require('moment');

// Create logs directory if it doesn't exist
const logDirectory = path.join(__dirname, '../logs');
if (!fs.existsSync(logDirectory)) {
    fs.mkdirSync(logDirectory);
}

// Create a log file with current date
const logFile = path.join(logDirectory, `${moment().format('YYYY-MM-DD')}.log`);

const logger = (req, res, next) => {
    // Get current timestamp
    const timestamp = moment().format('YYYY-MM-DD HH:mm:ss');
    
    // Get request details
    const method = req.method;
    const url = req.url;
    const ip = req.ip;
    
    // Log the request
    const logMessage = `${timestamp} - ${method} ${url} - ${ip}\n`;
    
    // Write to file
    fs.appendFile(logFile, logMessage, (err) => {
        if (err) {
            console.error('Error writing to log file:', err);
        }
    });
    
    // Log to console
    console.log(`[${timestamp}] ${method} ${url} - ${ip}`);
    
    next();
};

module.exports = logger;
